---
name: m365-chincopilot
description: "M365 tenant administration copilot (M365 ChinCopilot) driven by an MCP control matrix. Use when the task involves: (1) reading or updating the _M365TenantintraID_MCPControl.xlsx tenant/MCP control matrix, (2) resolving an M365 tenant (by intra ID, Entra tenant ID, primary domain, or display name) to its assigned MCP server endpoint, (3) preparing or executing M365 administrative operations (users, groups, licenses, Exchange, SharePoint, Teams, conditional access, audit/sign-in logs, usage reporting) through MCP tools, or (4) producing tenant audit or change records against the control matrix. Trigger on mentions of ChinCopilot, M365 ChinCopilot, MCP control matrix, tenant intra ID, M365 tenant MCP server, control matrix validation, or tenant resolution."
---

# M365 ChinCopilot

## Overview

Source of truth is the tenant/MCP control matrix (`_M365TenantintraID_MCPControl.xlsx`), which maps each M365 tenant (IntraID, Entra TenantId, PrimaryDomain, DisplayName) to the MCP server that fronts it. Always resolve the tenant against the matrix before invoking any MCP tool. Never guess an endpoint.

## Prerequisites check (run once per session)

1. **Control matrix present**: locate `_M365TenantintraID_MCPControl.xlsx`. If missing, build it from `assets/control_matrix_template.csv` via `scripts/build_matrix.py`, or ask the user for tenant rows. Do not proceed on assumed mappings.
2. **Validate matrix**: `python3 scripts/validate_control_matrix.py <xlsx> --json`. Exit 0 = valid, 1 = errors, 2 = warnings only. Fix errors before MCP calls.
3. **MCP server reachable**: for the resolved tenant, confirm the MCP server (stdio DLL or HTTP/SSE) starts and lists tools. For stdio probe `initialize`; for HTTP `GET /health` or the SSE endpoint.

## Core workflow

```
1. Identify target tenant(s) from the request (intra ID / tenant ID / domain / name).
2. Resolve each tenant: python3 scripts/resolve_tenant.py <query> [--json] [--include-disabled]
3. Validate prerequisites for the resolved MCP server.
4. Prepare MCP call: python3 scripts/mcp_payload.py <query> <operacao> [--json]
5. Execute. Read ops run freely; write ops confirm exact scope with user first.
6. Record change: python3 scripts/audit_log.py <query> --action "..." --object "..." --result success|partial|failed --note "..."
```

## Tenant resolution rules (enforced by resolve_tenant.py)

- Match by **IntraID** first (primary key).
- Then **Entra TenantId** (GUID), then **PrimaryDomain** (case-insensitive), then **DisplayName** (case-insensitive, prefix allowed).
- If multiple tenants match, stop and present candidates; never pick arbitrarily.
- If absent, report as unmanaged and ask whether to add a row.
- `Enabled=no/false` rows are skipped unless `--include-disabled`.

## Control matrix

Full schema, validation rules, and AuditLog format in `references/control-matrix-schema.md`. Required columns: `IntraID, TenantId, PrimaryDomain, DisplayName, McpServerMode (stdio|http), McpEndpoint, RuntimeVersion (expect 10.0.13)`. Optional: `Owner, Environment, Region, Enabled, Scopes, Notes, AuditLog`.

## Operation categories

Full tool catalog and parameter patterns in `references/m365-mcp-operations.md`. Categories: identity & users; groups & licensing; workloads (Exchange, SharePoint, Teams); security & governance (conditional access, audit/sign-in logs, risky users); reporting (license/usage, inactive users, guest inventory). Always verify actual tool names via `initialize`/`tools/list` on the resolved MCP server before calling.

## Safety rules

- **Read operations**: execute freely; cache results per tenant within the session.
- **Write operations** (create/update/delete/assign/reset): state the exact scope (tenant + object + fields) and get explicit confirmation unless the request already scoped it.
- **Destructive operations** (hard delete, license removal, CA disable, bulk changes): require explicit confirmation and always write an audit-log entry.
- Never run a write across all tenants unless the request explicitly says "all tenants".

## Output conventions (audit report — use this exact structure)

```
Tenant: <DisplayName> (IntraID=<…>, TenantId=<…>)
Operation: <verb> <object>
MCP server: <endpoint/mode>
Result: <success | partial | failed>
Details: <key fields changed / error message>
Audit: <timestamp> <agent> — recorded in matrix AuditLog column
```

For multi-tenant reports, produce a table (one row per tenant) with a status column, and call out any tenant that failed resolution or execution.

## Bundled scripts

| Script | Purpose |
|---|---|
| `scripts/validate_control_matrix.py <xlsx> [--json] [--sheet NAME]` | Validates matrix; dumps resolved tenant rows as JSON. |
| `scripts/resolve_tenant.py <query> [--json] [--include-disabled] [--matrix path]` | Resolves tenant by IntraID→GUID→domain→name; ambiguous/unmanaged flagged. |
| `scripts/mcp_payload.py <query> <operacao> [--filter F] [--top N] [--json]` | Emits MCP tool call payload with Graph authority and scope restrictions. Operations: users_list, users_get, users_create, groups_list, groups_create, users_assignLicense, ca_policies_list, signins_list, active_users_report, guests_inventory. |
| `scripts/audit_log.py <query> --action A --object O --result R --note N` | Append-only audit entry into the matrix AuditLog column. |
| `scripts/build_matrix.py` | Rebuilds a fresh valid `_M365TenantintraID_MCPControl.xlsx` from the template (one disabled example row + instructions sheet). |

Scripts require `openpyxl`. Test after any edit.
