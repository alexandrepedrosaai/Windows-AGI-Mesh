namespace TopologicalMajorana.Cell04 {
    open Microsoft.Quantum.Math;
    open Microsoft.Quantum.Convert;

    function StabilityScore(temperature : Double, deBroglieScaled : Double, coolingScaled : Double) : Double {
        let z = -0.80 * temperature + 2.00 * deBroglieScaled - 1.25 * coolingScaled;
        return 1.0 / (1.0 + Exp(-z));
    }

    @EntryPoint()
    operation Main() : Unit {
        let deepSpace = StabilityScore(2.725 / 288.0, 0.80, 0.05);
        let majoranaOptimal = StabilityScore(0.05 / 288.0, 1.0, 0.0);
        Message($"Celula 04: Deep Space={deepSpace}");
        Message($"Celula 04: Majorana Optimal={majoranaOptimal}");
    }
}