namespace TopologicalMajorana.Cell06 {
    open Microsoft.Quantum.Intrinsic;
    open Microsoft.Quantum.Measurement;
    open Microsoft.Quantum.Convert;

    operation BellValidation(shots : Int) : Int {
        mutable equal = 0;
        for _ in 1..shots {
            use qs = Qubit[2];
            H(qs[0]);
            CNOT(qs[0], qs[1]);
            let a = MResetZ(qs[0]);
            let b = MResetZ(qs[1]);
            if a == b { set equal += 1; }
        }
        return equal;
    }

    @EntryPoint()
    operation Main() : Unit {
        Message($"Celula 06: correlacoes Bell iguais = {BellValidation(100)} de 100");
    }
}