namespace TopologicalMajorana.Cell02 {
    open Microsoft.Quantum.Intrinsic;
    open Microsoft.Quantum.Measurement;
    open Microsoft.Quantum.Convert;

    operation QuantumPipeline(shots : Int) : (Int, Int) {
        mutable zeros = 0;
        mutable ones = 0;
        for _ in 1..shots {
            use q = Qubit();
            H(q);
            let r = MResetZ(q);
            if r == Zero { set zeros += 1; } else { set ones += 1; }
        }
        return (zeros, ones);
    }

    @EntryPoint()
    operation Main() : Unit {
        let (z, o) = QuantumPipeline(1200);
        Message($"Celula 02: 1200 amostras, Zero={z}, One={o}");
    }
}