namespace TopologicalMajorana.Cell01 {
    open Microsoft.Quantum.Intrinsic;
    open Microsoft.Quantum.Canon;
    open Microsoft.Quantum.Measurement;
    open Microsoft.Quantum.Convert;

    operation PrepareNormalizedState() : Result[] {
        use qs = Qubit[4];
        H(qs[0]);
        Ry(0.61, qs[1]);
        Ry(0.37, qs[2]);
        Ry(0.81, qs[3]);
        Controlled X([qs[0]], qs[1]);
        let result = ForEach(MResetZ, qs);
        return result;
    }

    operation MajoranaJordanWignerDemo() : Result[] {
        use qs = Qubit[2];
        H(qs[0]);
        CNOT(qs[0], qs[1]);
        // Demonstracao de operadores tipo Majorana via cadeias de Pauli.
        X(qs[0]);
        Y(qs[1]);
        return [MResetZ(qs[0]), MResetZ(qs[1])];
    }

    @EntryPoint()
    operation Main() : Unit {
        Message("Celula 01: Hilbert e Majorana");
        Message($"Estado medido: {PrepareNormalizedState()}");
        Message($"Majorana demo: {MajoranaJordanWignerDemo()}");
    }
}