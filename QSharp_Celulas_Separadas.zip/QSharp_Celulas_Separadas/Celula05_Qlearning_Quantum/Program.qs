namespace TopologicalMajorana.Cell05 {
    open Microsoft.Quantum.Intrinsic;
    open Microsoft.Quantum.Measurement;
    open Microsoft.Quantum.Random;
    open Microsoft.Quantum.Convert;

    operation ApplyAction(action : Int, q : Qubit) : Unit is Adj + Ctl {
        if action == 0 { H(q); }
        elif action == 1 { X(q); }
        elif action == 2 { Ry(0.1, q); }
        else { I(q); }
    }

    operation RunAgent(steps : Int) : Result {
        use q = Qubit();
        for _ in 1..steps {
            let action = DrawRandomInt(0, 3);
            ApplyAction(action, q);
        }
        return MResetZ(q);
    }

    @EntryPoint()
    operation Main() : Unit {
        Message($"Celula 05: resultado do agente quantico = {RunAgent(20)}");
        Message("A tabela Q e o treinamento numerico devem permanecer no host classico.");
    }
}