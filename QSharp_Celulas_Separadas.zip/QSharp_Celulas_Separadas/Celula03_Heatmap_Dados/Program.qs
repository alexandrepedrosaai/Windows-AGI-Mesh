namespace TopologicalMajorana.Cell03 {
    open Microsoft.Quantum.Math;
    open Microsoft.Quantum.Convert;

    function ProbabilityGrid(amplitudes : Double[]) : Double[] {
        mutable probs = [];
        for a in amplitudes {
            set probs += [a * a];
        }
        return probs;
    }

    @EntryPoint()
    operation Main() : Unit {
        let amplitudes = [0.50, 0.25, 0.10, 0.40, 0.30, 0.20, 0.45, 0.35];
        Message($"Celula 03: probabilidades para exportacao/heatmap = {ProbabilityGrid(amplitudes)}");
        Message("A renderizacao Seaborn permanece no host Python; Q# produz os dados.");
    }
}