# Q# por celula

Conversao modular do notebook fornecido. Cada pasta possui `Program.qs` e o respectivo `.csproj`.

## Mapeamento
1. Hilbert/Majorana
2. Pipeline e amostragem
3. Dados de probabilidade para heatmap
4. Pontuacao de estabilidade
5. Agente de acoes quanticas
6. Validacao Bell

## Observacao importante
Q# executa circuitos e logica quantica. NumPy/SciPy, graficos, matrizes arbitrarias, hashes e treinamento Q-learning numerico continuam sendo responsabilidades de um host Python ou C#. Os projetos usam o formato classico `Microsoft.Quantum.Sdk` porque foi solicitado um `.csproj` por celula. O QDK moderno tambem permite executar arquivos Q# diretamente pela extensao do VS Code.

## Execucao classica
Entre em uma pasta e execute `dotnet run`.
